jQuery('#datetimepicker').datetimepicker({
value:'01.02.2019 12:00',
format:'d.m.Y H:i',
startDate:'+2019/05/01 12:00',
minDate:'0',
step:15,
lang: 'ru'

});